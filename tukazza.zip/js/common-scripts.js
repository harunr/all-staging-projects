
(function($){
	$(function(){



        // Phone nav click function
        $('.menu-icon-wrap').click(function () {
            $("body").toggleClass("navShown");
            $(".nav-wrap").fadeIn()
        });

    
        
		
	})// End ready function.
    


})(jQuery)

